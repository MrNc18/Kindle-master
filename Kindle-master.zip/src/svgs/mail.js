export const mailSvg = <svg xmlns="http://www.w3.org/2000/svg" width="19.747" height="14.395" viewBox="0 0 19.747 14.395">
  <g id="Icon_feather-mail" data-name="Icon feather-mail" transform="translate(-2.304 -5.5)">
    <path id="Path_3073" data-name="Path 3073" d="M4.835,6H19.519a1.766,1.766,0,0,1,1.835,1.674V17.72a1.766,1.766,0,0,1-1.835,1.674H4.835A1.766,1.766,0,0,1,3,17.72V7.674A1.766,1.766,0,0,1,4.835,6Z" fill="none" stroke="#3856d5" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="Path_3074" data-name="Path 3074" d="M21.355,9l-9.177,6.38L3,9" transform="translate(0 -0.644)" fill="none" stroke="#3856d5" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
  </g>
</svg>
