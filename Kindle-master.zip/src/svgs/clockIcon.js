export const clockSCG = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="11.111"
    height="11.111"
    viewBox="0 0 11.111 11.111"
  >
    <path
      id="Icon_awesome-clock"
      data-name="Icon awesome-clock"
      d="M6.118.563a5.556,5.556,0,1,0,5.556,5.556A5.555,5.555,0,0,0,6.118.563ZM7.4,8.405,5.421,6.969a.271.271,0,0,1-.11-.217V2.982a.27.27,0,0,1,.269-.269H6.656a.27.27,0,0,1,.269.269V6.067L8.347,7.1a.269.269,0,0,1,.058.376l-.632.869A.271.271,0,0,1,7.4,8.405Z"
      transform="translate(-0.563 -0.563)"
    />
  </svg>
);
