export const blockSVG = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="18"
    height="18"
    viewBox="0 0 18 18"
  >
    <g
      id="Group_3265"
      data-name="Group 3265"
      transform="translate(-1811.6 -310)"
    >
      <path
        id="Icon_material-block"
        data-name="Icon material-block"
        d="M12,3a9,9,0,1,0,9,9A9,9,0,0,0,12,3ZM4.8,12A7.2,7.2,0,0,1,12,4.8a7.112,7.112,0,0,1,4.41,1.521L6.321,16.41A7.112,7.112,0,0,1,4.8,12ZM12,19.2a7.112,7.112,0,0,1-4.41-1.521L17.679,7.59A7.112,7.112,0,0,1,19.2,12,7.2,7.2,0,0,1,12,19.2Z"
        transform="translate(1808.6 307)"
        fill="#ff1616"
      />
    </g>
  </svg>
);
