export const locationSVG = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="10.445"
    height="13.927"
    viewBox="0 0 10.445 13.927"
  >
    <path
      id="Icon_awesome-map-marker-alt"
      data-name="Icon awesome-map-marker-alt"
      d="M4.686,13.646C.734,7.916,0,7.328,0,5.223a5.223,5.223,0,0,1,10.445,0c0,2.106-.734,2.694-4.686,8.423a.653.653,0,0,1-1.073,0ZM5.223,7.4A2.176,2.176,0,1,0,3.047,5.223,2.176,2.176,0,0,0,5.223,7.4Z"
      transform="translate(0)"
    />
  </svg>
);
