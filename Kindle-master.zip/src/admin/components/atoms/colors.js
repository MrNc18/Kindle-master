export default {
  bgColor: "#F1F1F1",
  red: "red",
  disabled: "#9EA0A5",
  header: "#EFF2FF",
  blue: "#3856D5",
  black: "#000",
  white: "#fff",
  bgLight: "#F9FBFD",
  gray: '#7b7b7b'
};
